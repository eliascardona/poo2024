Colocar el siguiente comando dentro de Windows CMD:

java -jar .\target\java-ventas-beta.jar