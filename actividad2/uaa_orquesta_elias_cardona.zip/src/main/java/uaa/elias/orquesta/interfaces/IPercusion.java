package uaa.elias.orquest.interfaces;

public interface IPercusion {
    void percudir();
}
