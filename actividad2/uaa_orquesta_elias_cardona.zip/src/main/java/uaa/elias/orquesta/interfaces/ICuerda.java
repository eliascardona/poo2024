package uaa.elias.orquesta.interfaces;

public interface ICuerda {
    void tocar();
}