package uaa.elias.orquest.interfaces;

public interface IViento {
    void soplar();
}