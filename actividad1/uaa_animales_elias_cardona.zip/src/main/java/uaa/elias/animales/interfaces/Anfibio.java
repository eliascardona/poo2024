package uaa.elias.animales.interfaces;

public interface Anfibio {
    void nadar();
    void caminar();
}


