package uaa.elias.animales.interfaces;

public interface Oviparo {
    void ponerHuevos();
}



