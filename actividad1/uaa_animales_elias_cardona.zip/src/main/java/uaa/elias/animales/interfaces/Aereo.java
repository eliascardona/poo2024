package uaa.elias.animales.interfaces;

public interface Aereo {
    void volar();
}


