package uaa.elias.animales.interfaces;

public interface Reptil {
    void reptar();
}


