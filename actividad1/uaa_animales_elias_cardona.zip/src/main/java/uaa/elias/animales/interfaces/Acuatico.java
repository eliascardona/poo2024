package uaa.elias.animales.interfaces;

public interface Acuatico {
    void nadar();
}


