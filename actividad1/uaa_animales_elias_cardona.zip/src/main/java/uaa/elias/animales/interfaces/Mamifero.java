package uaa.elias.animales.interfaces;

public interface Mamifero {
    void amamantar();
}


