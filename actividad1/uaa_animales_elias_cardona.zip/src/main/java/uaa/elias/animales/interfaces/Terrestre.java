package uaa.elias.animales.interfaces;

public interface Terrestre {
    void caminar();
}



