import java.util.Scanner;

public class Main {
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        int a, b, suma;

        System.out.print("Asigne un valor para su numero \"a\": ");
        a = scanner.nextInt();


        System.out.print("Asigne un valor para su numero \"b\": ");
        b = scanner.nextInt();

        suma = a + b;
        System.out.print("\nEl resultado de \"a\" + \"b\" es " + suma + "\n");


    }



}


















